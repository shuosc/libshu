#include<stdio.h>
int main(){
int a,b;
printf("Input two integers:");
scanf("%d%d",&a,&b);
printf("sum=%d\n",a+b);
printf("average=%.1f",(a+b)/2.0);
return 0;
}
