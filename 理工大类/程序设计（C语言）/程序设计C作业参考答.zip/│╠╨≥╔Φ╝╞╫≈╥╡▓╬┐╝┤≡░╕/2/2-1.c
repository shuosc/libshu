#include<stdio.h>
int main()
{int in;
char ch;
float fl;
scanf("%d%c%f",&in,&ch,&fl);
printf("%d %c %f",in,ch,fl);
return 0;
}
