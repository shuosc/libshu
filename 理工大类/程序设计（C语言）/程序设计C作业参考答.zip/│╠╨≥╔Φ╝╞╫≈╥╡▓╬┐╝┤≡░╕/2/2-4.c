#include <stdio.h>
int main(void)
{
    int num,ge,shi,bai;
    printf("Input a number:");
    scanf("%d",&num);
    ge=num%10;
    shi=(num%100)/10;
    bai=num/100;
    printf("%d %d %d",ge,shi,bai);
    return 0;
}
