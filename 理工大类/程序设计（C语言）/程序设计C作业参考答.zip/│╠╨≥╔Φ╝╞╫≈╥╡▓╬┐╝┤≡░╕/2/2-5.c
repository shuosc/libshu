#include <stdio.h>
int main()
{
    char a,b;
    scanf("%c%c",&a,&b);
    printf("Use putchar:");
    putchar(a+32);
    putchar(' ');
    putchar(b+32);
    printf("\nUse printf:%c %c",a+32,b+32);

}
