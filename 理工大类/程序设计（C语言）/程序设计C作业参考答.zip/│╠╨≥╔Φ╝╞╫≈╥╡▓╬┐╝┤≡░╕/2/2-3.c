#include <stdio.h>
#define PI 3.14159
int main (){
    double r,s;
    printf("Input radius:");
    scanf("%lf",&r);
    s=PI*r*r;
    printf("radius=%lf ",r);
    printf("area=%lf",s);
    return 0;
}
