#include<stdio.h>
int main()
{
double a,b,c;
scanf("%lf %lf %lf",&a,&b,&c);
if(a+b<=c||a+c<=b||b+c<=a||a==0||b==0||c==0)
printf("not triangle");
else if(a==b&&b==c)
printf("isosceles triangle");
else if(a==b||b==c||a==c)
printf("equilateral triangle");
else if(a*a+b*b==c*c||a*a==b*b+c*c||b*b==a*a+c*c)
printf("right triangle");
else
printf("arbitrary triangle");
return 0;
}
