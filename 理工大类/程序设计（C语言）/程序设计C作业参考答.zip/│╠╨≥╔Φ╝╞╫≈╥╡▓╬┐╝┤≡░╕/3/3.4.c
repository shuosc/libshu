#include<stdio.h>
int main()
{
 int x;
 scanf("%d",&x);
 if(x==0)
    printf("not within the scope of judgment");
 else{
   if(x>0)
        printf("positive ");
   else
        printf("negative ");
   if(x%2==0)
        printf("even number");
   else
        printf("odd number");
 }
    return 0;
}

