#include <stdio.h>
int main()
{
    int a,b,m,n;
    scanf("%d%d",&a,&b);
    m=a;
    n=b;
    if(a==b)
    {printf("The greatest common divisor:%d\n",a);
    printf("The lowest common multiple:%d",a);
    }
    else
    {while(a!=b)
    if(a>b)
    a=a-b;
    else
        b=b-a;
    printf("The greatest common divisor:%d\n",a);
    printf("The lowest common multiple:%d",m*n/a);
 }

