#include <stdio.h>
int main()
{
    char ch;
    ch=getchar();
    if('a'<=ch&&ch<='z')
        ch=ch-32;
    else if('A'<=ch&&ch<='Z')
            ch=ch+32;
    printf("%c",ch);
    return 0;
}
