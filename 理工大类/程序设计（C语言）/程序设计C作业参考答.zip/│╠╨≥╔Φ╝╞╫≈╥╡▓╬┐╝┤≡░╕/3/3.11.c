#include <stdio.h>
int main()
{
    int x,i;
    scanf("%d",&x);
    for(i=2;i<=x;i++)
    {
    if(x%i==0)
      break;}
   if(i!=x)
    printf("NO");
    else
    printf("YES");
}