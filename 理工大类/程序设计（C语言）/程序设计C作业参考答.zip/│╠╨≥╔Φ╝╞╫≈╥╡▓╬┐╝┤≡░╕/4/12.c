#define _CRT_SECURE_NO_WARNINGS
#include <stdio.h>
int main(void)
{
	int i;
	int m, n;
	int t;
	int num;
	printf("Input m: ");
	scanf("%d", &m);
	printf("Input n: ");
	scanf("%d", &n);
	for (i = m; i <= n; i++)
	{
		num = 0;
		t = i;
		while (t > 0)
		{
			num += (t % 10) * (t % 10) * (t % 10);
			t /= 10;
		}
		if (num == i)
		{
			printf("%d\n", i);
		}
	}
	return 0;
}