#define _CRT_SECURE_NO_WARNINGS
#include <stdio.h>
int main(void)
{
	int i;
	int ans = 0;
	int y, m, d;
	int s[13] = { 0, 31, 28, 31, 30, 31, 30, 31, 31, 30, 31, 30, 31 };
	printf("Input: ");
	scanf("%d %d %d", &y, &m, &d);
	for (i = 1; i < m; i++)
	{
		ans += s[i];
	}
	ans += d;
	if (m > 2 && ((y % 4 == 0 && y % 100 != 0) || y % 400 == 0))
	{
		ans++;
	}
	printf("%d\n", ans);
	return 0;
}