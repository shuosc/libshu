#define _CRT_SECURE_NO_WARNINGS
#include <stdio.h>
int main(void)
{
	double s = 0;
	double i = -2;
	double t = -1;
	double eps;
	printf("Input eps: ");
	scanf("%lf", &eps);
	do
	{
		i += 3;
		t *= -1;
		s += t * 1.0 / i;
	} while (eps * i <= 1);
	printf("s=%f\n", s);
	return 0;
}