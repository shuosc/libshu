#define _CRT_SECURE_NO_WARNINGS
#include <stdio.h>
int f[501];
int main(void)
{
	
	int i, j;
	int m, n;
	f[0] = 1;
	f[1] = 1;
	for (i = 4; i <= 500; i += 2)
	{
		f[i] = 1;
	}
	for (i = 3; i <= 22; i+=2)
	{
		if (f[i] == 0)
		{
			for (j = i * i; j <= 500; j += i)
			{
				f[j] = 1;
			}
		}
	}
	printf("Input m: ");
	scanf("%d", &m);
	printf("Input n: ");
	scanf("%d", &n);
	for (i = m, j = 0; i <= n; i++)
	{
		if (f[i] == 0)
		{
			if (j == 6)
			{
				printf("\n");
				j = 0;
			}
			printf("%4d", i);
			j++;
		}
	}
	printf("\n");
	return 0;
}