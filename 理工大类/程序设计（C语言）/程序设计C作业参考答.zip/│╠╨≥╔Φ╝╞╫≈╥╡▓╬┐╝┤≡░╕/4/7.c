#define _CRT_SECURE_NO_WARNINGS
#include <stdio.h>
int main(void)
{
	int i;
	int n;
	int a;
	int mmin = 2147483647;
	printf("Input n: ");
	scanf("%d", &n);
	printf("Input numbers: ");
	for (i = 0; i < n; i++)
	{
		scanf("%d", &a);
		if (a < mmin)
		{
			mmin = a;
		}
	}
	printf("min=%d\n", mmin);
	return 0;
}