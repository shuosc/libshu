#define _CRT_SECURE_NO_WARNINGS
#include <stdio.h>
int main(void)
{
	int n = 0;
	int num;
	printf("[1] Select apples\n[2] Select pears\n[3] Select oranges\n[4] Select grapes\n[0] exit\n");
	while (n < 5)
	{
		n++;
		printf("Enter choice: ");
		scanf("%d", &num);
		if (num == 0)
		{
			break;
		}
		else if (num == 1)
		{
			printf("[1]apples price = 3.0\n");
		}
		else if (num == 2)
		{
			printf("[2]pears price = 2.5\n");
		}
		else if (num == 3)
		{
			printf("[3]oranges price = 4.1\n");
		}
		else if (num == 4)
		{
			printf("[4]grapes price = 10.2\n");
		}
		else
		{
			printf("other price = 0.0\n");
		}
	}
	printf("Thanks\n");
	return 0;
}