#define _CRT_SECURE_NO_WARNINGS
#include <stdio.h>
#include <math.h>
int main(void)
{
	int i;
	double loan, rate;
	printf("Enter loan: ");
	scanf("%lf", &loan);
	printf("Enter rate: ");
	scanf("%lf", &rate);
	for (i = 5; i <= 30; i++)
	{
		printf("money(%.0f,%d)=%.0f\n", loan, i, loan * rate * pow(1 + rate, i * 12) / (pow(1 + rate, i * 12) - 1));
	}
	return 0;
}