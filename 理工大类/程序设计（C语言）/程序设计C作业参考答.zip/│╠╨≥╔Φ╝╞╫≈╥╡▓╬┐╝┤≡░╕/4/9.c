#define _CRT_SECURE_NO_WARNINGS
#include <stdio.h>
int main(void)
{
	int i;
	int a, n;
	int t;
	int ans = 0;
	printf("Input a, n: ");
	scanf("%d %d", &a, &n);
	t = a;
	for (i = 0; i < n; i++)
	{
		ans += t;
		t = t * 10 + a;
	}
	printf("s=%d\n", ans);
	return 0;
}