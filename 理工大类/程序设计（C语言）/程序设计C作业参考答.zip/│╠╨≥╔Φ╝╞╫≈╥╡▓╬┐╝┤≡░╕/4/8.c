#define _CRT_SECURE_NO_WARNINGS
#include <stdio.h>
int main(void)
{
	int i;
	double a = 2, b = 1;
	double t;
	int n;
	double s = 0;
	printf("Input n: ");
	scanf("%d", &n);
	for (i = 0; i < n; i++)
	{
		s += a / b;
		t = a + b;
		b = a;
		a = t;
	}
	printf("s=%.2f\n", s);
	return 0;
}