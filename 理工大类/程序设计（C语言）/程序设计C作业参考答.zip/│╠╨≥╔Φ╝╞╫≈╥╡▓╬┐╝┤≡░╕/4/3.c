#define _CRT_SECURE_NO_WARNINGS
#include <stdio.h>
int main(void)
{
	int i;
	int n;
	int s;
	int a[5];
	for (i = 0; i < 5; i++)
	{
		a[i] = 0;
	}
	printf("Enter n:");
	scanf("%d", &n);
	for (i = 1; i <= n; i++)
	{
		printf("Enter grade %d:", i);
		scanf("%d", &s);
		if (90 <= s && s <= 100)
		{
			a[0]++;
		}
		else if (80 <= s && s <= 89)
		{
			a[1]++;
		}
		else if (70 <= s && s <= 79)
		{
			a[2]++;
		}
		else if (60 <= s && s <= 69)
		{
			a[3]++;
		}
		else
		{
			a[4]++;
		}
	}
	printf("The number of A(90~100):%d\n", a[0]);
	printf("The number of B(80~89):%d\n", a[1]);
	printf("The number of C(70~79):%d\n", a[2]);
	printf("The number of D(60~69):%d\n", a[3]);
	printf("The number of E(0~59):%d\n", a[4]);
	return 0;
}