#define _CRT_SECURE_NO_WARNINGS
#include <stdio.h>
int main(void)
{
	int m, n;
	int a, b;
	int t;
	printf("Input m: ");
	scanf("%d", &a);
	m = a;
	printf("Input n: ");
	scanf("%d", &b);
	n = b;
	while (n > 0)
	{
		t = m % n;
		m = n;
		n = t;
	}
	printf("lcm=%d\n", a * b / m);
	printf("gcd=%d\n", m);
	return 0;
}
