#define _CRT_SECURE_NO_WARNINGS
#include <stdio.h>
int main(void)
{
	int i;
	double height;
	int n;
	double ans;
	printf("Input height: ");
	scanf("%lf", &height);
	printf("Input n: ");
	scanf("%d", &n);
	ans = height;
	for (i = 1; i < n; i++)
	{
		ans += height;
		height /= 2;
	}
	printf("distance=%.1f\n", ans);
	printf("height=%.1f\n", height / 2);
	return 0;
}