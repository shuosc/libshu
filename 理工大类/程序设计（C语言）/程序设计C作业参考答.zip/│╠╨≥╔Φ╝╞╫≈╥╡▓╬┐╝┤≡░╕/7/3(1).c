#define _CRT_SECURE_NO_WARNINGS
#include <stdio.h>
#include <string.h>
int main(void)
{
	int i;
	char c;
	char s[80];
	int len;
	int flag = -1;
	printf("Input a character:");
	scanf("%c", &c);
	printf("Input a string:");
	getchar();
	gets(s);
	len = strlen(s);
	for (i = 0; i < len; i++)
	{
		if (s[i] == c)
		{
			flag = i;
		}
	}
	if (flag == -1)
	{
		printf("NotFound\n");
	}
	else
	{
		printf("index=%d\n", flag);
	}
	return 0;
}