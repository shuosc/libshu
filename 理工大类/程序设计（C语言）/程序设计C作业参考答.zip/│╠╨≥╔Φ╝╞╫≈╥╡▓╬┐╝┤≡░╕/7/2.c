#define _CRT_SECURE_NO_WARNINGS
#include <stdio.h>
int main(void)
{
	int i, j;
	int n;
	printf("Input n:\n");
	scanf("%d", &n);
	printf("*");
	for (i = 1; i <= n; i++)
	{
		printf(" %d", i);
	}
	printf("\n");
	for (i = 1; i <= n; i++)
	{
		printf("%d", i);
		for (j = 1; j <= i; j++)
		{
			printf(" %d", i * j);
		}
		printf("\n");
	}
	return 0;
}