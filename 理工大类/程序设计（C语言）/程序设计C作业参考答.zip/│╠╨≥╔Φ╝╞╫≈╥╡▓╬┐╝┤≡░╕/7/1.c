#define _CRT_SECURE_NO_WARNINGS
#include <stdio.h>
#include <stdlib.h>
int main(void)
{
	int i, j;
	int a[6][6];
	int n;
	int sum = 0;
	printf("please input n:\n");
	scanf("%d", &n);
	printf("input a array:\n");
	for (i = 0; i < n; i++)
	{
		for (j = 0; j < n; j++)
		{
			scanf("%d", &a[i][j]);
		}
	}
	for (i = 0; i < n - 1; i++)
	{
		for (j = 0; j < n - 1; j++)
		{
			if (i + j == n - 1)
			{
				continue;
			}
			sum += a[i][j];
		}
	}
	printf("the sum=%d\n", sum);
	return 0;
}