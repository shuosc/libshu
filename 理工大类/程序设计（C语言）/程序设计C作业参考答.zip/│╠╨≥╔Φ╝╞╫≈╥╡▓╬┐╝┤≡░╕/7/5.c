#define _CRT_SECURE_NO_WARNINGS
#include <stdio.h>
#include <string.h>
int main(void)
{
	int i;
	char s[80];
	int len;
	printf("Input a string:");
	gets(s);
	len = strlen(s);
	for (i = 0; i < len; i++)
	{
		if (s[i] >= 'A' && s[i] <= 'Z')
		{
			s[i] = 'A' + 25 - (s[i] - 'A');
		}
	}
	printf("After replaced:%s\n", s);
	return 0;
}