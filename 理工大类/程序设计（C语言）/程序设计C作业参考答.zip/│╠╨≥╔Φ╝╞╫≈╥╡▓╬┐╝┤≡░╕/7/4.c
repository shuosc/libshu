#define _CRT_SECURE_NO_WARNINGS
#include <stdio.h>
#include <string.h>
int main(void)
{
	int i;
	char s[80];
	int len;
	int count = 0;
	printf("Input a string:");
	gets(s);
	len = strlen(s);
	for (i = 0; i < len; i++)
	{
		if (s[i] >= 'A' && s[i] <= 'Z' && s[i] != 'A' && s[i] != 'E' && s[i] != 'I' && s[i] != 'O' && s[i] != 'U')
		{
			count++;
		}
	}
	printf("count=%d\n", count);
	return 0;
}