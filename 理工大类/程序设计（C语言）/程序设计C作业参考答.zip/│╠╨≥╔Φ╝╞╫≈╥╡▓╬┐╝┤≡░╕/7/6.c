#define _CRT_SECURE_NO_WARNINGS
#include <stdio.h>
#include <string.h>
int main(void)
{
	int i,j;
	char s[80];
	int len;
	int temp;
	int ans = 0;
	printf("Input a string:");
	gets(s);
	len = strlen(s);
	for (i = len - 1,j=1; i >= 0; i--)
	{
		if (s[i] >= '0' && s[i] <= '9')
		{
			temp = s[i] - '0';
		}
		else if (s[i] >= 'A' && s[i] <= 'F')
		{
			temp = s[i] - 'A' + 10;
		}
		else
		{
			continue;
		}
		ans += temp * j;
		j *= 16;
	}
	printf("Hex=%d\n", ans);
	return 0;
}