#define _CRT_SECURE_NO_WARNINGS
#include <stdio.h>
#include <math.h>
int main(void)
{
	int i, j, k;
	int n;
	int a[10][10], b[10][10];
	scanf("%d", &n);
	for (i = 0; i < n; i++)
	{
		for (j = 0; j < n; j++)
		{
			scanf("%d", &a[i][j]);
		}
	}
	for (i = 0; i < n; i++)
	{
		for (j = 0; j < n; j++)
		{
			scanf("%d", &b[i][j]);
		}
	}
	for (i = 0; i < n; i++)
	{
		for (j = 0; j < n; j++)
		{
			if (i == j)
			{
				printf("%d ", b[i][n - j - 1]);
			}
			else
			{
				printf("%d ", a[i][j]);
			}
		}
		printf("\n");
	}
	printf("\n");
	for (i = 0; i < n; i++)
	{
		for (j = 0; j < n; j++)
		{
			if (i + j == n - 1)
			{
				printf("%d ", a[i][n - j - 1]);
			}
			else
			{
				printf("%d ", b[i][j]);
			}
		}
		printf("\n");
	}
	return 0;
}