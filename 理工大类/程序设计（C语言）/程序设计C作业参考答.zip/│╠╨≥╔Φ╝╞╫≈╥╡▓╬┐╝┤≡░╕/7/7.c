#define _CRT_SECURE_NO_WARNINGS
#include <stdio.h>
#include <string.h>
int main(void)
{
	int i;
	char s[80];
	int len;
	gets(s);
	len = strlen(s);
	for (i = 0; i < len; i++)
	{
		if (s[i] >= '0' && s[i] <= '9')
		{
			printf("%c", s[i]);
		}
	}
	printf("\n");
	return 0;
}