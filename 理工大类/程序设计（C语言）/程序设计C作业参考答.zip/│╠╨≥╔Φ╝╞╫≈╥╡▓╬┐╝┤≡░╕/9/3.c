#define _CRT_SECURE_NO_WARNINGS
#include <stdio.h>
#include <stdlib.h>
int fun(const void *sp1, const void *sp2)
{
	int *x = (int*)sp1;
	int *y = (int*)sp2;
	if (*x > *y)
	{
		return 1;
	}
	else if (*x < *y)
	{
		return -1;
	}
	else
	{
		return 0;
	}
}
int main(void)
{
	int a[200];
	int i;
	int n;
	printf("Input n:");
	scanf("%d", &n);
	printf("Input array of %d integers:", n);
	if (n > 0)
	{
		for (i = 0; i < n; i++)
		{
			scanf("%d", &a[i]);
		}
		qsort(a, n, sizeof(int), fun);
	}
	printf("After sorted the array is:");
	if (n > 0)
	{
		printf("%d", a[0]);
		for (i = 1; i < n; i++)
		{
			printf(" %d", a[i]);
		}
	}
	printf("\n");
	return 0;
}