#define _CRT_SECURE_NO_WARNINGS
#include <stdio.h>
#include <string.h>
int main(void)
{
	int i;
	char s[100], mmax[100];
	printf("Input 5 strings:\n");
	scanf("%s", mmax);
	for (i = 1; i < 5; i++)
	{
		scanf("%s", s);
		if (strcmp(s, mmax) > 0)
		{
			strcpy(mmax, s);
		}
	}
	printf("Max is:%s\n", mmax);
	return 0;
}