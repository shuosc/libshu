#define _CRT_SECURE_NO_WARNINGS
#include <stdio.h>
int search(int l[],int n,int x)
{
	int i;
	for (i = 0; i < n; i++)
	{
		if (l[i] == x)
		{
			break;
		}
	}
	return i;
}
int main(void)
{
	int i;
	int temp;
	int n;
	int x;
	int a[100];
	printf("Input n:");
	scanf("%d", &n);
	printf("Input %d integers:", n);
	for (i = 0; i < n; i++)
	{
		scanf("%d", &a[i]);
	}
	printf("Input x:");
	scanf("%d", &x);
	temp = search(a, n, x);
	if (temp < n)
	{
		printf("index = %d\n", temp);
	}
	else
	{
		printf("Not found\n");
	}
	return 0;
}