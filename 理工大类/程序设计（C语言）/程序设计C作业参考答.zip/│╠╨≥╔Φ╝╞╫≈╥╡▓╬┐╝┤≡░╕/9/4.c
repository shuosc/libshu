#include <stdio.h>
int find(int a[],int len,int n);
int main()
{
    int i,j=0;
    int n,m=0,x=1;
    static int a[10000],b[10000];
    printf("Input n(n must be a natural number less than 10000):");
    scanf("%d",&n);
    if(n>10000||n<=0)
    {
      printf("%d is out of range of valid values.",n);
      return 0;
    }
    while(j!=n-1)
    {
        for(i=0;i<n;i++)
        {
            if(a[i]==-1)
                continue;
            a[i]=x;
            if(a[i]==3)
            {
                a[i]=-1;
                b[j]=i+1;
                j++;
                x=0;
            }
            x++;
        }
    }
    for(i=1;i<=n;i++)
    {
        if(find(b,n-1,i)==0)
            m=i;
    }
    printf("Last No. is:%d",m);
    return 0;
}

int find(int a[],int len,int n)
{
    int i;
    for(i=0;i<len;i++)
    {
        if(a[i]==n)
            break;
    }
    if(i<len)
        return 1;
    else
        return 0;
}



