#define _CRT_SECURE_NO_WARNINGS
#include <stdio.h>
int main(void)
{
	int i;
	int n, m;
	int a[100];
	printf("Input n,m:");
	scanf("%d %d", &n, &m);
	if (m > n)
	{
		m %= n;
	}
	for (i = 0; i < n; i++)
	{
		scanf("%d", &a[i]);
	}
	printf("After move:");
	for (i = 0; i < n; i++)
	{
		printf("%5d", a[(n + i - m) % n]);
	}
	printf("\n");
	return 0;
}