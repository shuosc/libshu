#define _CRT_SECURE_NO_WARNINGS
#include <stdio.h>
#include <string.h>
int main(void)
{
	int i;
	char s[100], c;
	int len;
	printf("Input a string:");
	gets(s);
	len = strlen(s);
	printf("Input a char:");
	scanf("%c", &c);
	printf("After deleted,the string is:");
	for (i = 0; i < len; i++)
	{
		if (s[i] == c)
		{
			continue;
		}
		printf("%c", s[i]);
	}
	printf("\n");
	return 0;
}