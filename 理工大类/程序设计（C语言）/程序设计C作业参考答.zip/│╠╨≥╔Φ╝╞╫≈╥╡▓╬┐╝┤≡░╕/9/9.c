#define _CRT_SECURE_NO_WARNINGS
#include <stdio.h>
#include <string.h>
int main(void)
{
	int i;
	char s[100];
	int len;
	printf("Input a string:");
	gets(s);
	len = strlen(s);
	for (i = 0; i < len / 2; i++)
	{
		if (s[i] != s[len - i - 1])
		{
			break;
		}
	}
	if (i < len / 2)
	{
		printf("NO\n");
	}
	else
	{
		printf("YES\n");
	}
	return 0;
}