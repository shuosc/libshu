#define _CRT_SECURE_NO_WARNINGS
#include <stdio.h>
#include <string.h>
int main(void)
{
	int i;
	char s[5][100];
	int maxl, maxi, l;
	printf("Input 5 strings:");
	scanf("%s", s[0]);
	maxl = strlen(s[0]);
	maxi = 0;
	for (i = 1; i < 5; i++)
	{
		scanf("%s", s[i]);
		l = strlen(s[i]);
		if (l > maxl)
		{
			maxl = l;
			maxi = i;
		}
	}
	printf("The longest is:%s\n", s[maxi]);
	return 0;
}