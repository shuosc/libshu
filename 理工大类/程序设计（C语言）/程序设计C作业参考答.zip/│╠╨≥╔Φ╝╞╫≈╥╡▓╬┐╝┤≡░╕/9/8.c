#define _CRT_SECURE_NO_WARNINGS
#include <stdio.h>
#include <string.h>
int main(void)
{
	int i;
	char s[100];
	int len;
	int b;
	printf("Input a string:Input an integer:Output is:");
	gets(s);
	len = strlen(s);
	scanf("%d", &b);
	if (b <= 0)
	{
		printf("0");
	}
	else
	{
		for (i = b - 1; i < len; i++)
		{
			printf("%c", s[i]);
		}
	}
	printf("\n");
	return 0;
}