#define _CRT_SECURE_NO_WARNINGS
#include <stdio.h>
#include <string.h>
int main(void)
{
	int i;
	char s[100];
	int len;
	int ul = 0, ll = 0, sp = 0, di = 0, ot = 0;
	printf("Input a string:");
	gets(s);
	len = strlen(s);
	for (i = 0; i < len; i++)
	{
		if (s[i] >= 'A' && s[i] <= 'Z')
		{
			ul++;
		}
		else if (s[i] >= 'a' && s[i] <= 'z')
		{
			ll++;
		}
		else if (s[i] == ' ')
		{
			sp++;
		}
		else if (s[i] >= '0' && s[i] <= '9')
		{
			di++;
		}
		else
		{
			ot++;
		}
	}
	printf("Number of uppercase letters is :%d\n", ul);
	printf("Number of lowercase letters is :%d\n", ll);
	printf("Number of spacebars is :%d\n", sp);
	printf("Number of digits is :%d\n", di);
	printf("Number of other characters is :%d\n", ot);
	return 0;
}