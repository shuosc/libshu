#include <stdio.h>
int main()
{
    printf("Welcome to You!\n");
    return 0;
}
