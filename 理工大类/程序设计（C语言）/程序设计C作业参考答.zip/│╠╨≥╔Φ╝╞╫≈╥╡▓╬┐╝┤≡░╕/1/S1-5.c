# include <stdio.h>
int main()
{
    int math,eng,comp;
    float average;
    printf("math=");
    scanf("%d",&math);
    printf("eng=");
    scanf("%d",&eng);
    printf("comp=");
    scanf("%d",&comp);
    average=(math+eng+comp)/3.0;
    printf("average=%.2f\n",average);
    return 0;
}
