#include <stdio.h>
int main()
{
    int num1,num2,a,b,c,e;
    float d;
    scanf("%d/n",&num1);
    scanf("%d",&num2);
    a=num1+num2;
    b=num1-num2;
    c=num1*num2;
    d=(num1*1.00)/num2;
    e=num1%num2;
    printf("Enter num1:Enter num2:%d+%d=%d\n",num1,num2,a);
    printf("%d-%d=%d\n",num1,num2,b);
    printf("%d*%d=%d\n",num1,num2,c);
    printf("%d/%d=%.2f\n",num1,num2,d);
    printf("%d%%%d=%d\n",num1,num2,e);
    return 0;
}

