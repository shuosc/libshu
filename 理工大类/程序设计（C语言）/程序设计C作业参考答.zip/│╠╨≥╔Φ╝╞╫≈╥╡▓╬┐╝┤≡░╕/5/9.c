#include<stdio.h>
int main()
{
    int n,b,a,m,i=1;
  //  printf("n:");
    scanf("%d",&n);
  //printf("b:");
    scanf("%d",&b);
  //先计算从高到地的位数
    m=n;
    while (i<=m) {
      i=i*b;
    }
   i=i/b;

    do
    {
        a=n/i;
        if(a>9)
            printf("%c",a-10+'A');
        else                    /*��������ÿλ��*/
            printf("%d",a);
        n=n%i;
        i=i/b;
    }
    while(i!=0);/*�䵽����λֹͣ*/
    return 0;



}
