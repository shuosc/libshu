#include<stdio.h>
int main(void)
{
    int i=1,n;
    int x,y;
    printf("Input an integer: ");
    scanf("%d",&x);

    if(x<0)
    {
        x = -x;
        printf("- ");
    }
    y = x;

    while(x)//ѭ����x��λ��
    {
        x=x/10;
        i*=10;
    }
    for(i=i/10; i>0; i/=10) //����ȡ��x�ĸ�λ��
    {
        printf("%d ",n=y/i);
        y=y-n*i;
    }

    return 0;
}
