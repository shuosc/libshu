#include <stdio.h>

int isprime(int n)
{
    int i;
    for(i=2; i<=n/2; i++)
    {
        if (n%i==0)
        {
            return 0;
        }
    }
    return 1;
}

int main(void)
{
    int n,i,j,k,count=0,flag=0;
    scanf("%d",&n);
    for(i=6; i<=n; i+=2)
    {
        for(j=3; j<=i; j++)
        {
            for(k=j; k<=i; k++)
            {
                if(isprime(j) && isprime(k) && j+k==i)
                {
                    if(count==5)
                    {
                        count = 0;
                        printf("\n");
                    }
                    printf("%4d=%2d+%2d",i,j,k);
                    count++;
                    flag=1;//ֻ���һ��
                    break;
                }
            }
            if(flag==1){
                flag=0;
                break;
            }
        }
    }
    return 0;
}
