#include <stdio.h>
int main(void)
{
	int count = 0;
	int i, j, k;
	int num;
	printf("Input money: ");
	scanf("%d", &num);
	for (i = 1; i <= 20; i++)
	{
		for (j = 50; j >= 1; j--)
		{
			for (k = 1; k <= 100; k++)
			{
				if (i * 5 + j * 2 + k == num)
				{
					printf("fen5: %d fen2: %d fen1: %d\n", i, j, k);
					count++;
				}
			}
		}
	}
	printf("count=%d\n", count);
	return 0;
}
