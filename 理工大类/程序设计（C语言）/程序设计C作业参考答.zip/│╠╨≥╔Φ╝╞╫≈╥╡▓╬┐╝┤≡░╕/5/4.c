#include <stdio.h>
#include <stdlib.h>
int main(void)
{
	int x;
	printf("Enter x: ");
	scanf("%d", &x);
	if (x != 0)
	{
		printf("sign(%d)=%d\n", x, abs(x) / x);
	}
	else
	{
		printf("sign(0)=0\n");
	}
	return 0;
}
