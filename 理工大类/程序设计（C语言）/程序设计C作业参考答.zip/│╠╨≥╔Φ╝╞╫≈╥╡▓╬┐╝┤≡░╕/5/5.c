#include <stdio.h>
int main(void)
{
	double t1 = 1, temp;
	double t2 = 1;
	double sum = 0;
	int i = 0, j = 1;
	double e, x, xx;
	printf("e: ");
	scanf("%lf", &e);
	printf("x: ");
	scanf("%lf", &x);
	xx = x * x;
	temp = 1;
	while (temp >= e)
	{
		sum += j * temp;
		t1 *= xx;
		i++;
		t2 *= i;
		i++;
		t2 *= i;
		j *= -1;
		temp = t1 / t2;
	}
	sum += temp;
	printf("cos(x)=%.3f\n", sum);
	return 0;
}
