#include <stdio.h>
#include <stdlib.h>
int main(void)
{
	int num;
	int len = 0;
	int sum = 0;
	printf("Input an integer: ");
	scanf("%d", &num);
	num = abs(num);
	while (num > 0)
	{
		sum += num % 10;
		num /= 10;
		len++;
	}
	printf("count=%d sum=%d\n", len, sum);
	return 0;
}
