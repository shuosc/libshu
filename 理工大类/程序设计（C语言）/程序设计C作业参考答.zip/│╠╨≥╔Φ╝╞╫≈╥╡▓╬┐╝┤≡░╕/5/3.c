#include <stdio.h>
int main(void)
{
	int i, j;
	int n, m;
	scanf("%d %d", &n, &m);
	for (i = 0; i < n - 1; i++)
	{
		for (j = 0; j < m; j++)
		{
			printf(" ");
		}
		printf("C");
		printf("\n");
	}
	for (i = 0; i < m; i++)
	{
		printf(" ");
	}
	for (i = 0; i < (m + 1) / 2 + 1; i++)
	{
		printf("C");
	}
	printf("\n");
	for (i = 0; i < n - 1; i++)
	{
		for (j = 0; j < m; j++)
		{
			printf(" ");
		}
		printf("C");
		printf("\n");
	}
	for (i = 0; i < 2 * m + 1; i++)
	{
		printf("C");
	}
	printf("\n");
	return 0;
}
