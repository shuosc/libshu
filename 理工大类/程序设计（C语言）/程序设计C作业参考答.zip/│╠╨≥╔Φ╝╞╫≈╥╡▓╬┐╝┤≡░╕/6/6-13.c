#include<stdio.h>

int main(void)
{
	int count = 0;
	char a;
	printf("Input words: ");
	while (1)
	{
		a = getchar();
		if (a == ' ' || a == '\n')
			count++;
		if (a == '\n')
			break;
	}
	printf("count=%d", count);

	return 0;
}