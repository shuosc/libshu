#include<stdio.h>
#include<math.h>

int prime(int m)
{
	int i;
	for (i = 2; i <= sqrt(m); i++)
	{
		if (m%i == 0)
			return 0;
	}
	return 1;
}

int main(void)
{
	int k = 0;
	int i, j;
	for (i = 6; i <= 100; i = i + 2)
	{
		j = 3;
		while (1)
		{
			if (prime(j) == 1 && prime(i - j) == 1)
			{
				printf("%4d=%2d+%2d", i, j, i - j);
				k++;
				break;
			}
			j++;
		}
		if (k == 5)
		{
			printf("\n");
			k = 0;
		}
	}

	return 0;
}