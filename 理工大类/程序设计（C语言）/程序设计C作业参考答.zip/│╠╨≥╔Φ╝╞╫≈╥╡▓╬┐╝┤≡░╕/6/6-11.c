#include<stdio.h>
#include<math.h>

int fun(int n)
{
	int reverse = 0;
	int sign = 1;
	int temp;
	if (n < 0)
	{
		n = -n;
		sign = -1;
	}

	while (1)
	{
		temp = n % 10;
		reverse = reverse * 10 + temp;
		n = n / 10;
		if (n == 0)
			break;
	}

	return reverse*sign;
}

int main(void)
{
	int m1, m2;
	printf("Input m1: ");
	scanf("%d", &m1);
	printf("Input m2: ");
	scanf("%d", &m2);
	printf("%d's reverse is: %d\n", m1, fun(m1));
	printf("%d's reverse is: %d", m2, fun(m2));

	return 0;
}