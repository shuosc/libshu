#include<stdio.h>

int fn(int a, int n)
{
	int i;
	int sum = 0;
	for (i = 1; i <= n; i++)
	{
		sum = sum * 10 + a;
	}
	return sum;
}
int main(void)
{
	int a, n;
	printf("Input a: ");
	scanf("%d", &a);
	printf("Input n: ");
	scanf("%d", &n);
	int sum = 0;
	int i;
	for (i = 1; i <= n; i++)
	{
		sum = sum + fn(a, i);
	}
	printf("sum=%d", sum);

	return 0;
}