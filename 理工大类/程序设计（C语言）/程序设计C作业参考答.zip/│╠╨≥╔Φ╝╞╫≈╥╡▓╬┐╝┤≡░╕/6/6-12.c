#include<stdio.h>
#include<math.h>

int fib(int n)
{
	int fn = 0;
	int i;
	int a1 = 1, a2 = 1;
	for (i = 3; i <= n; i++)
	{
		fn = a1 + a2;
		a1 = a2;
		a2 = fn;
	}
	return fn;
}

int main(void)
{
	int m, n;
	printf("Input m: ");
	scanf("%d", &m);
	printf("Input n: ");
	scanf("%d", &n);

	int i = 3;
	int temp;
	while (1)
	{
		temp = fib(i);
		if (temp >= m&&temp <= n)
			printf("%d ", temp);
		if (temp > n)
			break;
		i++;
	}

	return 0;
}