#include<stdio.h>
#include<math.h>

int prime(int m)
{
	int i;
	if (m > 1)
	{
		for (i = 2; i <= sqrt(m); i++)
		{
			if (m%i == 0)
			{
				return 0;
			}
		}
		return 1;
	}
	else
		return 0;
}

int main(void)
{
	int m, n;
	printf("Input m: ");
	scanf("%d", &m);
	printf("Input n: ");
	scanf("%d", &n);
	int count = 0, sum = 0;
	int i;
	for (i = m; i <= n; i++)
	{
		count = count + prime(i);
		sum = sum + prime(i)*i;
	}
	printf("count=%d, sum=%d", count, sum);

	return 0;
}