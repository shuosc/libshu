#include<stdio.h>

int main(void)
{
	char a;
	int letter = 0, blank = 0, digit = 0, other = 0;
	while (1)
	{
		a = getchar();
		if (a == '\n')
			break;
		if ((a >= 'a'&&a <= 'z') || (a >= 'A'&&a <= 'Z'))
			letter++;
		else if (a >= '0'&&a <= '9')
			digit++;
		else if (a == ' ')
			blank++;
		else
			other++;
	}
	printf("letter=%d,blank=%d,digit=%d,other=%d", letter, blank, digit, other);


	return 0;
}