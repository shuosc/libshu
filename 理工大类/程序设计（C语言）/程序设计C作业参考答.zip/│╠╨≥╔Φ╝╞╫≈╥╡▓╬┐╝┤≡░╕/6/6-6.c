#define _CRT_SECURE_NO_WARNINGS
#include <stdio.h>
int main(void)
{
	int num;
	printf("Input a decimal: ");
	scanf("%d", &num);
	printf("The octal is %o\n", num);
	printf("The hexadecimal is %X\n", num);
	return 0;
}