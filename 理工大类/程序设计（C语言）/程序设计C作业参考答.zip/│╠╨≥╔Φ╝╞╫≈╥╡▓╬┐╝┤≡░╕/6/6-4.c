#include<stdio.h>
#include<math.h>

int countdigit(int number, int digit)
{
	int temp;
	int count = 0;
	while (number != 0)
	{
		temp = number % 10;
		if (temp == 2)
			count++;
		number = number / 10;
	}
	return count;
}

int main(void)
{
	int num;
	printf("Enter an integer: ");
	scanf("%d", &num);
	printf("Number of digit 2: %d", countdigit(num, 2));

	return 0;
}