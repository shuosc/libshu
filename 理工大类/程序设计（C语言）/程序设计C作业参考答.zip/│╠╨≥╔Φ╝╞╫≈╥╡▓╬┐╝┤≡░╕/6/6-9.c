#include<stdio.h>

int factorsum(int number)
{
	int sum = 0;
	int i;
	if (number > 1)
	{
		for (i = 1; i < number; i++)
		{
			if (number%i == 0)
				sum = sum + i;
		}
	}
	if (number == 1)
		sum = 1;
	return sum;
}

int main(void)
{
	int m, n;
	printf("Input m: ");
	scanf("%d", &m);
	printf("Input n: ");
	scanf("%d", &n);

	int i;
	for (i = m; i <= n; i++)
	{
		if (i == factorsum(i))
			printf("%5d", i);
	}


	return 0;
}