#include<stdio.h>
#include<math.h>

int is(int number)
{
	int n = number;
	int temp, sum = 0;
	while (n > 0)
	{
		temp = n % 10;
		sum = sum + pow(temp, 3);
		n = n / 10;
	}
	if (sum == number)
		printf("%d\n", number);
	return 0;
}

int main(void)
{
	int m, n;
	printf("Input m: ");
	scanf("%d", &m);
	printf("Input n: ");
	scanf("%d", &n);

	int i;
	for (i = m; i <= n; i++)
	{
		is(i);
	}


	return 0;
}