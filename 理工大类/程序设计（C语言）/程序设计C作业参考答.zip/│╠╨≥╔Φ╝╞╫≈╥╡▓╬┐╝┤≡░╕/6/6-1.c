#include<stdio.h>
#include<math.h>
int even(int n)
{
	if (n % 2 == 1)
		return 1;
	else
		return 0;
}

int main(void)
{
	int temp = 1;
	int sum = 0;
	printf("Input integers: ");
	while (temp > 0)
	{
		scanf("%d", &temp);
		sum = sum + temp*even(temp);
	}
	printf("The sum of the odd numbers is %d", sum);
	return 0;
}